# 推播通知所需檔案盤點

1. npm: next-pwa/ web-push/ 
2. next.config.ts
3. worker/index.js
4. manifest.json
5. service-worker.js (next-pwa 在 build 時自行產生)
6. .gitignore