/** 定義通知權限狀態 enum */
enum PermissionStatus {
  Default = 'default',
  Denied = 'denied',
  Granted = 'granted',
}

export default PermissionStatus;
